// Better Days prototype runtime.
// This is a small local runtime for the BetterDays.dc.html design prototype.
(function () {
  function readValue(values, path) {
    return path.trim().split('.').reduce(function (value, key) {
      return value == null ? undefined : value[key];
    }, values);
  }

  function renderTemplate(template, values, actions, resolveAction) {
    var wrapper = document.createElement('div');
    wrapper.innerHTML = template;

    wrapper.querySelectorAll('*').forEach(function (node) {
      var rawAction = node.getAttribute('onclick') || node.getAttribute('onClick');
      if (rawAction) node.setAttribute('data-dc-handler', rawAction);
    });

    wrapper.querySelectorAll('sc-if').forEach(function (node) {
      var condition = node.getAttribute('value') || '';
      var match = condition.match(/{{\s*([^}]+)\s*}}/);
      var visible = match ? Boolean(readValue(values, match[1])) : false;
      if (visible) node.replaceWith.apply(node, Array.from(node.childNodes));
      else node.remove();
    });

    wrapper.querySelectorAll('*').forEach(function (node) {
      Array.from(node.attributes).forEach(function (attribute) {
        if (attribute.name === 'data-dc-handler') return;
        var value = attribute.value.replace(/{{\s*([^}]+)\s*}}/g, function (_, path) {
          var result = readValue(values, path);
          return result == null ? '' : String(result);
        });
        if (attribute.name.toLowerCase() === 'onclick') {
          node.removeAttribute(attribute.name);
        } else {
          node.setAttribute(attribute.name, value);
        }
      });
    });

    var walker = document.createTreeWalker(wrapper, NodeFilter.SHOW_TEXT);
    var text;
    while ((text = walker.nextNode())) {
      text.nodeValue = text.nodeValue.replace(/{{\s*([^}]+)\s*}}/g, function (_, path) {
        var result = readValue(values, path);
        return result == null ? '' : String(result);
      });
    }

    wrapper.querySelectorAll('[data-dc-handler]').forEach(function (node) {
      var action = node.getAttribute('data-dc-handler').match(/{{\s*([^}]+)\s*}}/);
      var actionName = action && action[1].trim();
      node.onclick = function () {
        var liveValues = resolveAction(actionName);
        if (typeof liveValues === 'function') liveValues();
      };
      node.removeAttribute('data-dc-handler');
    });
    return wrapper;
  }

  function boot() {
    var root = document.querySelector('x-dc');
    var script = document.querySelector('script[data-dc-script]');
    if (!root || !script) return;
    var template = root.innerHTML;
    var source = script.textContent || '';
    var Component = new Function('DCLogic', source + '\nreturn Component;')(
      function DCLogic(props) { this.props = props || {}; this.state = {}; }
    );
    var instance = new Component({ startScreen: 'welcome' });
    var mount = document.createElement('div');
    mount.id = 'dc-root';
    root.replaceWith(mount);

    function update() {
      var values = instance.renderVals();
      var actions = values.actions || {};
      mount.replaceChildren(renderTemplate(template, values, actions, function (name) {
        var current = instance.renderVals();
        return current[name] || (current.actions && current.actions[name]);
      }));
    }
    instance.setState = function (patch) {
      instance.state = Object.assign({}, instance.state, patch);
      update();
    };
    update();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
