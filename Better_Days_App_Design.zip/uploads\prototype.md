 # Prototype - Better Days low-fidelity wireframes

 - Date: 2026-09-08
 - Fidelity: **low - layout and content only**
 - Product: Better Days Wellbeing Companion

 These wireframes define the content and behavior of the MVP. Visual styling,
 colors, type, and spacing can be refined by the designer. The product must stay
 calm, private, accessible, and non-clinical.

 ---

 ## S1 - Welcome and consent · FE1

 ```
 +--------------------------------+
 |          Better Days           |
 |     A private wellbeing tool   |
 |                                |
 |  Reflect on habits and choose  |
 |  small actions that may help.  |
 |                                |
 |  This is not diagnosis, therapy|
 |  or emergency care.            |
 |                                |
 |  [ ] I understand the limits   |
 |  [ ] I agree to the privacy    |
 |      and wellbeing information |
 |                                |
 |             [ Continue ]       |
 +--------------------------------+
 ```

 Consent must be explicit and stored with the accepted text version and time.

 ## S2 - Onboarding questionnaire · FE2

 ```
 +--------------------------------+
 |  Getting to know your routine  |
 |              3 of 12           |
 |                                |
 |  How has your sleep felt       |
 |  recently?                     |
 |                                |
 |  1      2      3      4      5 |
 |  low                           high
 |                                |
 |          [ Back ] [ Next ]     |
 +--------------------------------+
 ```

 Questions cover sleep, stress, connection, enjoyable activity, work/study, and
 functioning. The user can review answers before submitting.

 ## S3 - Progress profile · FE3

 ```
 +--------------------------------+
 |        Your current snapshot  |
 |                                |
 |       BUILDING HABITS         |
 |  A neutral reflection profile,|
 |  not a medical assessment.    |
 |                                |
 |  Sleep       3.2 / 5           |
 |  Stress      2.8 / 5           |
 |  Connection  3.7 / 5           |
 |  Activity    2.9 / 5           |
 |                                |
 |  Focus area: stress and rest  |
 |       [ See small actions ]    |
 +--------------------------------+
 ```

 Area scores remain visible. Safety concerns are never represented by this
 profile alone.

 ## S4 - Daily check-in · FE4

 ```
 +--------------------------------+
 |       Today's check-in        |
 |          under 2 minutes      |
 |                                |
 |  Mood          1  2  3  4  5  |
 |  Sleep         1  2  3  4  5  |
 |  Stress        1  2  3  4  5  |
 |  Connection    1  2  3  4  5  |
 |  Activity      1  2  3  4  5  |
 |                                |
 |  Optional note [              ]|
 |             [ Save check-in ] |
 +--------------------------------+
 ```

 Optional notes remain private and are included in export and deletion.

 ## S5 - Small recommendations · FE5

 ```
 +--------------------------------+
 |          Small next steps      |
 |                                |
 |  Based on your recent check-in:|
 |                                |
 |  [ ] Put your phone away 20    |
 |      minutes before bed        |
 |      Focus: sleep and rest     |
 |                                |
 |  [ ] Message someone you trust |
 |      Focus: connection         |
 |                                |
 |  [ Done ] [ Skip ] [ Save ]    |
 +--------------------------------+
 ```

 Suggestions must not provide diagnosis, medication advice, or treatment.

 ## S6 - Weekly summary · FE6

 ```
 +--------------------------------+
 |        Your week in view       |
 |                                |
 |  Check-ins completed     5 / 7 |
 |  Sleep          reported higher|
 |  Stress         reported lower |
 |  Connection     about the same |
 |                                |
 |  What helped this week?        |
 |  [                            ] |
 |                                |
 |  [ Set a goal for next week ]  |
 +--------------------------------+
 ```

 Use neutral trends. Never label the user's mental or physical health.

 ## S7 - Private journal · FE7

 ```
 +--------------------------------+
 |          Private reflection    |
 |                                |
 |  This note is private to you.  |
 |                                |
 |  [ Write what you noticed... ] |
 |                                |
 |  [ Save privately ]             |
 +--------------------------------+
 ```

 Private reflections are clearly separated from community submissions.

 ## S8 - Community stories · FE8

 ```
 +--------------------------------+
 |        Community stories       |
 |  Personal experiences, reviewed |
 |  before publication.            |
 |                                |
 |  Finding a calmer morning      |
 |  A student's reflection        |
 |                         [ Read ]|
 |                                |
 |  [ Share a story for review ]  |
 |  [ Report a story ]             |
 +--------------------------------+
 ```

 Stories remain private until moderation is complete.

 ## S9 - Safety support · FE9

 ```
 +--------------------------------+
 |          You deserve support   |
 |  If you may be in immediate     |
 |  danger, contact local emergency|
 |  services or a trusted person.  |
 |                                |
 |  Find professional support:     |
 |  [ Local support information ]  |
 |  [ Crisis resources ]           |
 |  [ Return to Better Days ]      |
 +--------------------------------+
 ```

 This screen is separate from scoring and does not claim to assess safety.

 ## S10 - Privacy and data management · FE1, FE10

 ```
 +--------------------------------+
 |       Your data and privacy    |
 |  Data stored: check-ins,       |
 |  profile, journal, preferences |
 |                                |
 |  Consent status: Active         |
 |  [ Download my data ]           |
 |  [ Change consent ]             |
 |  [ Delete my account ]          |
 +--------------------------------+
 ```

 Destructive deletion requires a clear confirmation and an auditable workflow.

 ## Screen-to-feature map

 | Screen | Features |
 |---|---|
 | S1 Welcome and consent | FE1 |
 | S2 Onboarding | FE2 |
 | S3 Progress profile | FE3 |
 | S4 Daily check-in | FE4 |
 | S5 Recommendations | FE5 |
 | S6 Weekly summary | FE6 |
 | S7 Private journal | FE7 |
 | S8 Community stories | FE8 |
 | S9 Safety support | FE9 |
 | S10 Data management | FE1, FE10 |
