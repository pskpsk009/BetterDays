// Lightweight iOS-style device frame for the Better Days prototype.
function IOSDevice({ children, width = 402, height = 874 }) {
  return (
    <div style={{ width, height, borderRadius: 42, overflow: 'hidden', position: 'relative', background: '#F4F1EA', boxShadow: '0 24px 70px rgba(31,48,45,.22)', fontFamily: 'system-ui, sans-serif' }}>
      <div style={{ position: 'absolute', top: 10, left: '50%', transform: 'translateX(-50%)', width: 118, height: 30, borderRadius: 20, background: '#1C2926', zIndex: 2 }} />
      <div style={{ height: '100%', overflow: 'auto' }}>{children}</div>
      <div style={{ position: 'absolute', bottom: 9, left: '50%', transform: 'translateX(-50%)', width: 128, height: 5, borderRadius: 99, background: 'rgba(28,41,38,.55)' }} />
    </div>
  );
}
