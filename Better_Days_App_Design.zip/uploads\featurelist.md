 # Feature List - Better Days Wellbeing Companion

 - Date: 2026-09-08
 - Source: `Better_Days_Project_Charter.md`
 - Phase: DISCOVER / MVP planning

 Requirements describe what users need; this list describes what gets built. A
 feature is Core when it supports the Better Days MVP. Acceptance criteria must
 be testable without diagnosing or judging a user.

 ---

 ## FE1 - Account, Privacy and Consent - **Core**

 Covers account creation, wellbeing limitations, privacy settings, and data rights.

 | # | Acceptance criteria |
 |---|---|
 | AC1 | A user can create an account and read the wellbeing-support limitations before continuing. |
 | AC2 | Consent records store the user, accepted text version, timestamp, and withdrawal status. |
 | AC3 | The interface explains what wellbeing information is collected and why. |
 | AC4 | A user can view, export, correct, and request deletion of personal data. |
 | AC5 | A user cannot access another user's check-ins, journal entries, or profile. |

 ## FE2 - Onboarding Questionnaire - **Core**

 Covers the 10 to 15-question baseline questionnaire.

 | # | Acceptance criteria |
 |---|---|
 | AC1 | A user can complete 10 to 15 questions using a clear 1-to-5 scale. |
 | AC2 | Questions cover sleep, stress, connection, enjoyable activity, work or study balance, and functioning. |
 | AC3 | A user can review and correct answers before submitting. |
 | AC4 | The system validates required answers and does not silently invent missing responses. |
 | AC5 | Questionnaire wording avoids diagnosis, treatment claims, and negative labels. |

 ## FE3 - Wellbeing Scoring and Progress Profile - **Core**

 Covers deterministic focus-area scoring and the neutral progress profile.

 | # | Acceptance criteria |
 |---|---|
 | AC1 | The system calculates separate scores for each approved focus area. |
 | AC2 | The weighted overall score uses documented weights and deterministic logic. |
 | AC3 | The user receives exactly one neutral profile: Starting Point, Building Habits, or Maintaining Progress. |
 | AC4 | The screen shows individual area scores as well as the overall result. |
 | AC5 | The profile states that it is not a medical diagnosis or clinical assessment. |
 | AC6 | Serious-concern answers are evaluated separately and cannot be hidden by the weighted score. |
 | AC7 | Scoring examples and boundary cases are covered by automated tests. |

 ## FE4 - Daily Check-In - **Core**

 Covers short repeated reflections about current habits and feelings.

 | # | Acceptance criteria |
 |---|---|
 | AC1 | A user can record mood, sleep, stress, connection, activity, and work or study balance. |
 | AC2 | Optional notes can be added without being required for submission. |
 | AC3 | A typical check-in can be completed in under two minutes. |
 | AC4 | A user can edit or delete a check-in according to the data policy. |
 | AC5 | A serious-concern response triggers separate support messaging and is not converted into a diagnosis. |

 ## FE5 - Personalized Recommendations - **Core**

 Covers one or two small actions based on lower-scoring focus areas.

 | # | Acceptance criteria |
 |---|---|
 | AC1 | Recommendations identify the focus area they relate to. |
 | AC2 | Recommendations are practical, respectful, and suitable for self-directed habit building. |
 | AC3 | Recommendations do not provide medication advice, diagnosis, or treatment instructions. |
 | AC4 | A user can mark a recommendation as completed, skipped, or saved for later. |
 | AC5 | Optional future AI recommendations require explicit disclosure, data minimization, and safety review. |

 ## FE6 - Weekly Progress Summary - **Core**

 Covers neutral seven-day trends and reflection.

 | # | Acceptance criteria |
 |---|---|
 | AC1 | A user can view check-in completion and focus-area trends for the previous week. |
 | AC2 | Trends use neutral wording such as "reported higher" or "reported lower". |
 | AC3 | The summary does not label a user healthy, unhealthy, recovered, depressed, or at risk. |
 | AC4 | The summary includes a reflection prompt or goal for the next week. |
 | AC5 | Empty or incomplete weeks are explained without misleading charts or conclusions. |

 ## FE7 - Private Reflection Journal - **Core**

 Covers private notes and personal goals.

 | # | Acceptance criteria |
 |---|---|
 | AC1 | A user can create, edit, view, and delete a private journal entry. |
 | AC2 | Journal entries are private by default and are not shown in community stories. |
 | AC3 | Journal entries are included in the user's export and deletion workflows. |
 | AC4 | The interface clearly distinguishes private reflections from public submissions. |

 ## FE8 - Moderated Community Stories - **Core**

 Covers reading stories and submitting content for moderation.

 | # | Acceptance criteria |
 |---|---|
 | AC1 | Users can read only stories that have passed the moderation workflow. |
 | AC2 | A user can submit a story for review without making it immediately public. |
 | AC3 | Users can report harmful content, harassment, dangerous advice, or exposed personal information. |
 | AC4 | Stories do not claim to be professional, medically verified, or suitable for every person. |
 | AC5 | Moderation actions are logged and private journal entries remain inaccessible to moderators unless explicitly submitted. |

 ## FE9 - Safety Support - **Core**

 Covers professional-support and crisis-resource information.

 | # | Acceptance criteria |
 |---|---|
 | AC1 | Safety-support information is reachable from the main application navigation. |
 | AC2 | Serious-concern responses show supportive next steps separately from scores and recommendations. |
 | AC3 | The interface tells users to contact local emergency services or a trusted person when immediate danger is present. |
 | AC4 | The system never claims to determine whether a user is safe. |
 | AC5 | Safety copy is reviewed by a qualified wellbeing advisor before release. |

 ## FE10 - Privacy and Audit Layer - **Core** *(cross-cutting)*

 Covers secure handling, auditability, and deletion across every feature.

 | # | Acceptance criteria |
 |---|---|
 | AC1 | Relevant access, consent, export, edit, moderation, and deletion actions are logged with user and timestamp. |
 | AC2 | Required access or traffic logs are retained for at least 90 days under applicable rules. |
 | AC3 | Account deletion removes account-linked wellbeing content through a controlled, auditable process. |
 | AC4 | Data exports contain only the requesting user's permitted data. |
 | AC5 | No user-facing copy describes Better Days as a diagnostic or treatment service. |

 ## Not built in the first MVP

 - Automated diagnosis or mental-health risk classification.
 - AI crisis assessment or autonomous safety decisions.
 - Unmoderated public posting.
 - Sharing private journals with other users.

 ## MVP build order

 **FE1 -> FE2 -> FE3 -> FE4 -> FE5 -> FE6**, with FE7, FE9, and FE10 running
 alongside the core flow. FE8 is released only when moderation and reporting are
 ready.
