 # User Journey - the Better Days core workflow

 - Date: 2026-09-08
 - Persona: **A student or young adult** who wants to understand daily routines,
	 build manageable habits, and notice gradual progress without being diagnosed.
 - Workflow: **consent -> baseline reflection -> profile -> daily check-in ->
	 small action -> weekly summary**

 ## Step-by-step

 | # | Screen | User does | System does | Traces | Pain relieved |
 |---|---|---|---|---|---|
 | J1 | Welcome / consent | Reads the privacy explanation and wellbeing limitations, then accepts | Stores consent version, user, and timestamp | FE1 | Trust and privacy concern |
 | J2 | Onboarding | Answers 10 to 15 questions about sleep, stress, connection, activity, and functioning | Validates answers and saves the baseline securely | FE2 | Lack of self-awareness |
 | J3 | Progress profile | Reviews area scores and the profile label | Calculates deterministic scores and shows neutral explanations | FE3 | Unclear next steps |
 | J4 | Recommendation | Chooses one suggested small action | Shows one or two practical actions linked to lower-scoring areas | FE5 | Advice feels too broad |
 | J5 | Daily check-in | Records a short update about mood, sleep, stress, connection, activity, and study/work | Saves the check-in and keeps completion under two minutes | FE4 | Inconsistent tracking |
 | J6 | Daily support | Marks an action completed, skipped, or saved | Records the action response without judging the user | FE5 | Difficulty maintaining habits |
 | J7 | Weekly summary | Reviews the previous seven days and writes an optional reflection | Shows neutral trends, check-in count, and a next-week prompt | FE6, FE7 | Progress is hard to see |
 | J8 | Safety support | Opens support information when concerned or prompted by an answer | Shows professional and crisis resources separately from the profile | FE9 | Serious concern needs appropriate support |
 | J9 | Privacy settings | Exports or deletes personal information | Produces the permitted export or performs controlled deletion | FE1, FE10 | Lack of control over data |

 ## Alternate and failure paths

 | # | Trigger | System behaviour | Traces |
 |---|---|---|---|
 | A1 | User skips optional check-in fields | Saves the completed required fields and explains what was omitted | FE4 |
 | A2 | Required onboarding answer is missing | Highlights the missing answer and does not calculate a misleading profile | FE2 |
 | A3 | Serious-concern response is selected | Shows supportive safety information separately; never returns a diagnosis | FE3, FE9 |
 | A4 | User withdraws consent | Stops the affected processing, records withdrawal, and explains the impact | FE1, FE10 |
 | A5 | Weekly data is incomplete | Shows an incomplete-week message rather than an unsupported conclusion | FE6 |
 | A6 | Story is submitted | Keeps it private until moderation is complete | FE8 |
 | A7 | Unauthorized user requests private data | Denies access and records the security event | FE1, FE10 |
 | A8 | Account deletion is confirmed | Deletes account-linked content and shows a completion message | FE1, FE10 |

 ## Drop-off risks

 | Risk | Where | Mitigation | Traces |
 |---|---|---|---|
 | Onboarding feels like a long survey | J2 | Keep it to 10 to 15 questions, show progress, and use one question per screen where helpful | FE2 |
 | Users interpret the profile as a diagnosis | J3 | Use neutral labels, plain limitations, and separate area scores | FE3 |
 | Daily check-ins feel repetitive | J5 | Keep the flow under two minutes and make optional notes optional | FE4 |
 | Recommendations feel generic | J4 | Link every suggestion to a focus area and offer only one or two actions | FE5 |
 | Safety messaging feels alarming | J8 | Use calm, supportive wording and make resources easy to reach from anywhere | FE9 |
 | Users do not trust private data handling | J1, J9 | Explain collection, access, export, deletion, and consent status clearly | FE1, FE10 |
 | Community content causes harm | J6, J7 | Moderate before publication and provide reporting controls | FE8 |

 ## Problem coverage check

 - **Self-awareness problem** -> J2, J3, J5, J7
 - **Unclear next steps** -> J3, J4, J6
 - **Inconsistent tracking** -> J5, J7, J9
